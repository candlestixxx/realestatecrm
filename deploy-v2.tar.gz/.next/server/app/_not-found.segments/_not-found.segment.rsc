1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/0882nio1w1j89.js","/_next/static/chunks/0chd2xabol7uj.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
3:I[837457,["/_next/static/chunks/0882nio1w1j89.js","/_next/static/chunks/0chd2xabol7uj.js","/_next/static/chunks/0i.l9589uvx0j.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"WJesc0ZKy77Ra8yPWpa7H"}
