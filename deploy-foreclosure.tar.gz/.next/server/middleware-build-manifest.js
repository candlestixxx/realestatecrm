globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/26BDTvpSCS5zrE27sIxlc/_buildManifest.js",
    "static/26BDTvpSCS5zrE27sIxlc/_ssgManifest.js",
    "static/26BDTvpSCS5zrE27sIxlc/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0k4i9j0fxp9m6.js",
    "static/chunks/16-n9ghktqw.s.js",
    "static/chunks/019427s.j46os.js",
    "static/chunks/12cpzyeqsto_-.js",
    "static/chunks/0.ocyjqtww49j.js",
    "static/chunks/turbopack-0~y420koptl.a.js"
  ]
};
