var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contacts/route.js")
R.c("server/chunks/[root-of-the-server]__0gygsjs._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_contacts_route_actions_11x3m9k.js")
R.m(37349)
module.exports=R.m(37349).exports
