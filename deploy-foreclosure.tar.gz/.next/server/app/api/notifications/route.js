var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__0520dio._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_notifications_route_actions_02pd93..js")
R.m(31181)
module.exports=R.m(31181).exports
