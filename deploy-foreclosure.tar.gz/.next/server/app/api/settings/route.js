var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/route.js")
R.c("server/chunks/[root-of-the-server]__0ic2vgo._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_next_104s5bu._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_settings_route_actions_0sb6w~_.js")
R.m(75357)
module.exports=R.m(75357).exports
