var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/settings/reset/route.js")
R.c("server/chunks/[root-of-the-server]__0ck6oj-._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_settings_reset_route_actions_0vlb3ml.js")
R.m(18855)
module.exports=R.m(18855).exports
