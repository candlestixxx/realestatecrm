var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/route.js")
R.c("server/chunks/[root-of-the-server]__0-87306._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/00qh_foreclosureworkflow__next-internal_server_app_api_leads_route_actions_0fwhlad.js")
R.m(30446)
module.exports=R.m(30446).exports
