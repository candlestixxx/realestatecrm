var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/bulk/route.js")
R.c("server/chunks/[root-of-the-server]__0gjrq93._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_next_104s5bu._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_leads_bulk_route_actions_07_rdi-.js")
R.m(4218)
module.exports=R.m(4218).exports
