var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0.zvb23._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_leads_[id]_route_actions_0m_yr.t.js")
R.m(45721)
module.exports=R.m(45721).exports
