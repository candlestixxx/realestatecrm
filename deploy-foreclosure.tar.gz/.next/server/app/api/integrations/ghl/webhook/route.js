var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/ghl/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0-95i6y._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_integrations_ghl_webhook_route_actions_0542rgv.js")
R.m(6018)
module.exports=R.m(6018).exports
