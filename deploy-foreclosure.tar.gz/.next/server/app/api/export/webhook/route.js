var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/export/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0rsuiu1._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_export_webhook_route_actions_0~a37tp.js")
R.m(32231)
module.exports=R.m(32231).exports
