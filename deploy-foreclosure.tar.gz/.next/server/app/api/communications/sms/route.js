var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/communications/sms/route.js")
R.c("server/chunks/[root-of-the-server]__0ab2_5a._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_communications_sms_route_actions_0z1awwo.js")
R.m(58885)
module.exports=R.m(58885).exports
