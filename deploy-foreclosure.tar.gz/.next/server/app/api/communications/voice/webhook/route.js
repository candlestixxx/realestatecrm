var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/communications/voice/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__01mmtl5._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/12-~_next-internal_server_app_api_communications_voice_webhook_route_actions_0b9~pha.js")
R.m(59405)
module.exports=R.m(59405).exports
