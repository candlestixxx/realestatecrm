var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/communications/voice/route.js")
R.c("server/chunks/[root-of-the-server]__0ioawjm._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/[root-of-the-server]__0_zgnvs._.js")
R.c("server/chunks/[root-of-the-server]__0mg14at._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_communications_voice_route_actions_0lwkzc3.js")
R.m(45055)
module.exports=R.m(45055).exports
