var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/communications/email/route.js")
R.c("server/chunks/[root-of-the-server]__0z4140d._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_communications_email_route_actions_0pg7mbf.js")
R.m(88988)
module.exports=R.m(88988).exports
