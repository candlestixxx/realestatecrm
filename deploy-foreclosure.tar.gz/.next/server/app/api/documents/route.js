var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/route.js")
R.c("server/chunks/[root-of-the-server]__0jmu6cy._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/[root-of-the-server]__0_zgnvs._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_documents_route_actions_0bwc1i9.js")
R.m(5895)
module.exports=R.m(5895).exports
