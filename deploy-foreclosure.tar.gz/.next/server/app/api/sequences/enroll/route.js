var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sequences/enroll/route.js")
R.c("server/chunks/[root-of-the-server]__0rfbq7c._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/0h8d_zod_v4_classic_external_0hh122y.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_sequences_enroll_route_actions_0mdl25u.js")
R.m(50116)
module.exports=R.m(50116).exports
