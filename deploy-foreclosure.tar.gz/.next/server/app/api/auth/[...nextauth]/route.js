var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__0hufzt3._.js")
R.c("server/chunks/workspace_realestatecrm_apps_foreclosureworkflow_12k0hcz._.js")
R.c("server/chunks/[root-of-the-server]__0_zgnvs._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0wq___next-internal_server_app_api_auth_[___nextauth]_route_actions_122ofkm.js")
R.m(62805)
module.exports=R.m(62805).exports
