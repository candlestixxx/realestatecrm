var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notes/route.js")
R.c("server/chunks/[root-of-the-server]__026j_4v._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/00qh_foreclosureworkflow__next-internal_server_app_api_notes_route_actions_0_ihfsr.js")
R.m(53856)
module.exports=R.m(53856).exports
