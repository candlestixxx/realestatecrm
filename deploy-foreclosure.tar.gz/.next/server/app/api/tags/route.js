var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tags/route.js")
R.c("server/chunks/[root-of-the-server]__0x_9jnj._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/00qh_foreclosureworkflow__next-internal_server_app_api_tags_route_actions_0gs9s31.js")
R.m(29219)
module.exports=R.m(29219).exports
