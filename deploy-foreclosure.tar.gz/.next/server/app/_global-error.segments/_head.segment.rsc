1:"$Sreact.fragment"
2:I[14279,["/_next/static/chunks/012qzgww6i1.o.js","/_next/static/chunks/0w~gq1f87xa5j.js"],"ViewportBoundary"]
3:I[14279,["/_next/static/chunks/012qzgww6i1.o.js","/_next/static/chunks/0w~gq1f87xa5j.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[1823,["/_next/static/chunks/012qzgww6i1.o.js","/_next/static/chunks/0w~gq1f87xa5j.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"26BDTvpSCS5zrE27sIxlc"}
