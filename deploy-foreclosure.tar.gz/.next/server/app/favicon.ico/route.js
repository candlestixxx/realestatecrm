var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/0h8d_next_dist_esm_build_templates_app-route_08pz8kq.js")
R.c("server/chunks/0h8d_next_01j4sc9._.js")
R.c("server/chunks/[root-of-the-server]__0a4awfd._.js")
R.c("server/chunks/00qh_foreclosureworkflow__next-internal_server_app_favicon_ico_route_actions_0vjax2q.js")
R.m(36263)
module.exports=R.m(36263).exports
