1:"$Sreact.fragment"
2:I[70887,["/_next/static/chunks/0mb0vj2y0wz83.js","/_next/static/chunks/0w~gq1f87xa5j.js","/_next/static/chunks/05hjpoe~5ob6k.js"],"default"]
3:I[87420,["/_next/static/chunks/0mb0vj2y0wz83.js","/_next/static/chunks/0w~gq1f87xa5j.js","/_next/static/chunks/05hjpoe~5ob6k.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"26BDTvpSCS5zrE27sIxlc"}
