module.exports=[12639,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_communications_sms_route_actions_0z1awwo.js.map