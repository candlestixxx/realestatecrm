module.exports=[37385,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_settings_reset_route_actions_0vlb3ml.js.map