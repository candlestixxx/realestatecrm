module.exports=[43341,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_integrations_ghl_webhook_route_actions_0542rgv.js.map