module.exports=[1617,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_communications_email_route_actions_0pg7mbf.js.map