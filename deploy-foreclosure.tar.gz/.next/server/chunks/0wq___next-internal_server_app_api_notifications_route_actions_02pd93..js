module.exports=[86497,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_notifications_route_actions_02pd93..js.map