module.exports=[34443,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_communications_voice_route_actions_0lwkzc3.js.map