module.exports=[95185,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_settings_route_actions_0sb6w~_.js.map