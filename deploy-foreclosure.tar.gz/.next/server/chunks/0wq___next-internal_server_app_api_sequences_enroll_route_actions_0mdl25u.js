module.exports=[360,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_sequences_enroll_route_actions_0mdl25u.js.map