module.exports=[5615,(a,b,c)=>{}];

//# sourceMappingURL=06nx_apps_foreclosureworkflow__next-internal_server_app_leads_page_actions_1317557.js.map