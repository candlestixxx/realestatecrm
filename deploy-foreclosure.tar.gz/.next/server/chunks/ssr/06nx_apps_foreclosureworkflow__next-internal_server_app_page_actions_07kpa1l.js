module.exports=[12619,(a,b,c)=>{}];

//# sourceMappingURL=06nx_apps_foreclosureworkflow__next-internal_server_app_page_actions_07kpa1l.js.map