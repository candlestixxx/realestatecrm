module.exports=[37690,(a,b,c)=>{}];

//# sourceMappingURL=06nx_apps_foreclosureworkflow__next-internal_server_app_login_page_actions_0-vkj0n.js.map