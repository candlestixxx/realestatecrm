module.exports=[35061,(a,b,c)=>{}];

//# sourceMappingURL=00qh_foreclosureworkflow__next-internal_server_app_segments_page_actions_0kc9uzo.js.map