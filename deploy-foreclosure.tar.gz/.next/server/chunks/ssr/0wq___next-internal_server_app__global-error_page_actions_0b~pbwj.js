module.exports=[13578,(a,b,c)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app__global-error_page_actions_0b~pbwj.js.map