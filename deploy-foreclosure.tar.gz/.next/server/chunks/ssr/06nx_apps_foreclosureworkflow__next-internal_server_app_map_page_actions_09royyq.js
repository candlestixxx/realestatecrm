module.exports=[20921,(a,b,c)=>{}];

//# sourceMappingURL=06nx_apps_foreclosureworkflow__next-internal_server_app_map_page_actions_09royyq.js.map