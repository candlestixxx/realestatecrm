module.exports=[20745,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_documents_route_actions_0bwc1i9.js.map