module.exports=[24262,(e,o,d)=>{}];

//# sourceMappingURL=12-~_next-internal_server_app_api_communications_voice_webhook_route_actions_0b9~pha.js.map