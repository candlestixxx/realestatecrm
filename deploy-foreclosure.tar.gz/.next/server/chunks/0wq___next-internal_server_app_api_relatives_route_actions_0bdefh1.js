module.exports=[55486,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_relatives_route_actions_0bdefh1.js.map