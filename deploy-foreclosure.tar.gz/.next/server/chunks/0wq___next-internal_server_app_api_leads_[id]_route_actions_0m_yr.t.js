module.exports=[3258,(e,o,d)=>{}];

//# sourceMappingURL=0wq___next-internal_server_app_api_leads_%5Bid%5D_route_actions_0m_yr.t.js.map