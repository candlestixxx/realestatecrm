globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/omkqUQLlNvqKyYCW9ikXh/_buildManifest.js",
    "static/omkqUQLlNvqKyYCW9ikXh/_ssgManifest.js",
    "static/omkqUQLlNvqKyYCW9ikXh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ae9w-nr5ni~n.js",
    "static/chunks/0k6c9i47ki3cm.js",
    "static/chunks/12nge3j-x9tc1.js",
    "static/chunks/0~rk~iesp54ct.js",
    "static/chunks/128aahewwf1we.js",
    "static/chunks/0.636t5m33j3w.js",
    "static/chunks/turbopack-0ye.gm6wluz_~.js"
  ]
};
