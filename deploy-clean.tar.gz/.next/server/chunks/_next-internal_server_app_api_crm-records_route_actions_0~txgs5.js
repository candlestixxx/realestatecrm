module.exports=[82524,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crm-records_route_actions_0~txgs5.js.map