module.exports=[134395,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_partner-permissions_route_actions_0ztj43q.js.map