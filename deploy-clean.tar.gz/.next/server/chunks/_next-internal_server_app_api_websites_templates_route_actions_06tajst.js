module.exports=[805772,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_websites_templates_route_actions_06tajst.js.map