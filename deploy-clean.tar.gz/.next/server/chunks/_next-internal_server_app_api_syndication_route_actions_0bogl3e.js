module.exports=[291562,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_syndication_route_actions_0bogl3e.js.map