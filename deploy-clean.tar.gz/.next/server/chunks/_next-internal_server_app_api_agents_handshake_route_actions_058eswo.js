module.exports=[244635,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_agents_handshake_route_actions_058eswo.js.map