module.exports=[137695,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_deal-stakeholders_route_actions_0os8avw.js.map