module.exports=[247625,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_integrations_trigger_voice_route_actions_0inrnjr.js.map