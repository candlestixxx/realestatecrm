module.exports=[228283,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_idx_search_route_actions_114.i64.js.map