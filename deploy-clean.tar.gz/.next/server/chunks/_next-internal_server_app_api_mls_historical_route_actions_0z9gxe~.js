module.exports=[149446,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mls_historical_route_actions_0z9gxe~.js.map