module.exports=[610917,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lead-gen_social_route_actions_0~0caja.js.map