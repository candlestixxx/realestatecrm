module.exports=[888647,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_crm-records_%5BrecordId%5D_route_actions_0_.jbhy.js.map