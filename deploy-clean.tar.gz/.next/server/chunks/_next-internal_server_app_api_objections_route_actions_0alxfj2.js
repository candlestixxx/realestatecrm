module.exports=[399608,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_objections_route_actions_0alxfj2.js.map