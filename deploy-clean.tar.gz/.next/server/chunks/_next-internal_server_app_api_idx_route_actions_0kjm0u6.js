module.exports=[944478,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_idx_route_actions_0kjm0u6.js.map