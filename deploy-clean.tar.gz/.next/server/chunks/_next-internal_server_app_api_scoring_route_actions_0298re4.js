module.exports=[704520,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_scoring_route_actions_0298re4.js.map