module.exports=[380140,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_leads_latest-unread_route_actions_00lu2tw.js.map