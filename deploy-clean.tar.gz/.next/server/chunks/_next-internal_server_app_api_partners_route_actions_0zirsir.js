module.exports=[263568,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_partners_route_actions_0zirsir.js.map