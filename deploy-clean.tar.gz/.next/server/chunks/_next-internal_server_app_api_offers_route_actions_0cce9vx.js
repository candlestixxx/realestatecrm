module.exports=[26277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_offers_route_actions_0cce9vx.js.map