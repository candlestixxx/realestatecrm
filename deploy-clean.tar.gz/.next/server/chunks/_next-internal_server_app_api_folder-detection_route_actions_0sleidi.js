module.exports=[721901,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_folder-detection_route_actions_0sleidi.js.map