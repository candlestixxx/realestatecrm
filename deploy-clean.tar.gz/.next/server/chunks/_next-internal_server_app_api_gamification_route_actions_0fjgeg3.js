module.exports=[995817,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_gamification_route_actions_0fjgeg3.js.map