module.exports=[731368,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_voice_accent-morphing_route_actions_0oylxwc.js.map