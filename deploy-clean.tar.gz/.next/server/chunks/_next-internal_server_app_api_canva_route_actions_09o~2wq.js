module.exports=[345055,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_canva_route_actions_09o~2wq.js.map