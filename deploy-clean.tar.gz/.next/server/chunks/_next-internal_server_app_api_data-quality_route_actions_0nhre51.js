module.exports=[517910,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_data-quality_route_actions_0nhre51.js.map