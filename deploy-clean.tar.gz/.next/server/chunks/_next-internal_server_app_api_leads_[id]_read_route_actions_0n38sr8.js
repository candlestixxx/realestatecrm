module.exports=[644865,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_leads_%5Bid%5D_read_route_actions_0n38sr8.js.map