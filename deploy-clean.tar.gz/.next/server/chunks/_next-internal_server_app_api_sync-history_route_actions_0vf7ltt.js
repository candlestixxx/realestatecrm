module.exports=[796273,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sync-history_route_actions_0vf7ltt.js.map