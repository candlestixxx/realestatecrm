module.exports=[25250,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_property-data_route_actions_0voh5h9.js.map