var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/deal-requirements/route.js")
R.c("server/chunks/[root-of-the-server]__0yg.ij.._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_deal-requirements_route_actions_0by87w3.js")
R.m(650914)
module.exports=R.m(650914).exports
