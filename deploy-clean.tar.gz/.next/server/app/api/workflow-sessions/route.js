var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/workflow-sessions/route.js")
R.c("server/chunks/[root-of-the-server]__0k8d1_c._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_workflow-sessions_route_actions_03wbfd3.js")
R.m(563805)
module.exports=R.m(563805).exports
