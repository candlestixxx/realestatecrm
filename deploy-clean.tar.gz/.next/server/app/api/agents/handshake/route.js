var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agents/handshake/route.js")
R.c("server/chunks/[root-of-the-server]__0q49de7._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_agents_handshake_route_actions_058eswo.js")
R.m(620190)
module.exports=R.m(620190).exports
