var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/voice/accent-morphing/route.js")
R.c("server/chunks/[root-of-the-server]__0n3p5~t._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_voice_accent-morphing_route_actions_0oylxwc.js")
R.m(72595)
module.exports=R.m(72595).exports
