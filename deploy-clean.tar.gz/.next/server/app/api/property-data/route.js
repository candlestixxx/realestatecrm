var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/property-data/route.js")
R.c("server/chunks/[root-of-the-server]__0xex6r9._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_property-data_route_actions_0voh5h9.js")
R.m(816252)
module.exports=R.m(816252).exports
