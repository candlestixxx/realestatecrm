var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/client-portal/route.js")
R.c("server/chunks/[root-of-the-server]__0tdt_xi._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_client-portal_route_actions_0iqt~v6.js")
R.m(330446)
module.exports=R.m(330446).exports
