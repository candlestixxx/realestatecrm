var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/deal-stakeholders/route.js")
R.c("server/chunks/[root-of-the-server]__10229sl._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_deal-stakeholders_route_actions_0os8avw.js")
R.m(931335)
module.exports=R.m(931335).exports
