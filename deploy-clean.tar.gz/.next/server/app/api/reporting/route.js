var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/reporting/route.js")
R.c("server/chunks/[root-of-the-server]__0kfz80s._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_reporting_route_actions_0sx_sym.js")
R.m(251939)
module.exports=R.m(251939).exports
