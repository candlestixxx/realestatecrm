var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/syndication/route.js")
R.c("server/chunks/[root-of-the-server]__0s30fdf._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_syndication_route_actions_0bogl3e.js")
R.m(942917)
module.exports=R.m(942917).exports
