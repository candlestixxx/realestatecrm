var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/voice-settings/route.js")
R.c("server/chunks/[root-of-the-server]__0njxv5u._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_voice-settings_route_actions_0ld4cwh.js")
R.m(93215)
module.exports=R.m(93215).exports
