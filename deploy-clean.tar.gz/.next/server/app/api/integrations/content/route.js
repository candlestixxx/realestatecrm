var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/content/route.js")
R.c("server/chunks/[root-of-the-server]__0p~p07.._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_integrations_content_route_actions_0d9_kjp.js")
R.m(571179)
module.exports=R.m(571179).exports
