var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/media/route.js")
R.c("server/chunks/[root-of-the-server]__06xnydc._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_integrations_media_route_actions_0yxw9o2.js")
R.m(791849)
module.exports=R.m(791849).exports
