var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/trigger/voice/route.js")
R.c("server/chunks/[root-of-the-server]__0~kdkp-._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_integrations_trigger_voice_route_actions_0inrnjr.js")
R.m(436701)
module.exports=R.m(436701).exports
