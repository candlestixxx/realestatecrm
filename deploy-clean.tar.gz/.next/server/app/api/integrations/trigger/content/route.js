var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/integrations/trigger/content/route.js")
R.c("server/chunks/[root-of-the-server]__0cu70xj._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_integrations_trigger_content_route_actions_0f.34l3.js")
R.m(891054)
module.exports=R.m(891054).exports
