var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/offers/route.js")
R.c("server/chunks/[root-of-the-server]__02s8.t0._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_offers_route_actions_0cce9vx.js")
R.m(814867)
module.exports=R.m(814867).exports
