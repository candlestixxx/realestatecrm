var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/myplusleads/route.js")
R.c("server/chunks/[root-of-the-server]__0zwqk39._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_myplusleads_route_actions_03c67_t.js")
R.m(362864)
module.exports=R.m(362864).exports
