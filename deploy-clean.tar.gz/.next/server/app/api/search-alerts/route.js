var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/search-alerts/route.js")
R.c("server/chunks/[root-of-the-server]__0i4jwdw._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_search-alerts_route_actions_0mjosau.js")
R.m(272606)
module.exports=R.m(272606).exports
