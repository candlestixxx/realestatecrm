var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/mls/historical/route.js")
R.c("server/chunks/[root-of-the-server]__10sd~k~._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_mls_historical_route_actions_0z9gxe~.js")
R.m(106158)
module.exports=R.m(106158).exports
