var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/canva/route.js")
R.c("server/chunks/[root-of-the-server]__02x2l~.._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_canva_route_actions_09o~2wq.js")
R.m(755694)
module.exports=R.m(755694).exports
