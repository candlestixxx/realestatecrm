var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agentcore/voice-command/route.js")
R.c("server/chunks/[root-of-the-server]__0mayede._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_agentcore_voice-command_route_actions_08y2trr.js")
R.m(401636)
module.exports=R.m(401636).exports
