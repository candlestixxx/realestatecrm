var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/partners/route.js")
R.c("server/chunks/[root-of-the-server]__075-gjb._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_partners_route_actions_0zirsir.js")
R.m(981871)
module.exports=R.m(981871).exports
