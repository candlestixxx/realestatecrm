var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/scoring/route.js")
R.c("server/chunks/[root-of-the-server]__0pu6_xo._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_scoring_route_actions_0298re4.js")
R.m(457506)
module.exports=R.m(457506).exports
