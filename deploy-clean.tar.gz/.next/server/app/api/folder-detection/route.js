var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/folder-detection/route.js")
R.c("server/chunks/[root-of-the-server]__0~mmhb2._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_folder-detection_route_actions_0sleidi.js")
R.m(312508)
module.exports=R.m(312508).exports
