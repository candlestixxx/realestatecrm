var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contracts/route.js")
R.c("server/chunks/[root-of-the-server]__0afyph8._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_contracts_route_actions_054xnvs.js")
R.m(453270)
module.exports=R.m(453270).exports
