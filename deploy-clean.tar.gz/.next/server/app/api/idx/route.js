var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/idx/route.js")
R.c("server/chunks/[root-of-the-server]__0g841i_._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_idx_route_actions_0kjm0u6.js")
R.m(986118)
module.exports=R.m(986118).exports
