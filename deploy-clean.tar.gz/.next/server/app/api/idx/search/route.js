var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/idx/search/route.js")
R.c("server/chunks/[root-of-the-server]__13lzh_2._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_idx_search_route_actions_114.i64.js")
R.m(729830)
module.exports=R.m(729830).exports
