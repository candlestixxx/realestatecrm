var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/objections/route.js")
R.c("server/chunks/[root-of-the-server]__0ljpfnz._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_objections_route_actions_0alxfj2.js")
R.m(217442)
module.exports=R.m(217442).exports
