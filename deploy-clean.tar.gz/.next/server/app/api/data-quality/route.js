var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/data-quality/route.js")
R.c("server/chunks/[root-of-the-server]__0~lv1jv._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_data-quality_route_actions_0nhre51.js")
R.m(272417)
module.exports=R.m(272417).exports
