var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/listings/route.js")
R.c("server/chunks/[root-of-the-server]__0vrusli._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_listings_route_actions_0syg3~f.js")
R.m(91126)
module.exports=R.m(91126).exports
