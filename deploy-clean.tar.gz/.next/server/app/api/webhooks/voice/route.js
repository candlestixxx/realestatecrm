var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/voice/route.js")
R.c("server/chunks/[root-of-the-server]__0zw89bw._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_webhooks_voice_route_actions_07kikr6.js")
R.m(446772)
module.exports=R.m(446772).exports
