var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/route.js")
R.c("server/chunks/[root-of-the-server]__0_e8qyn._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_websites_route_actions_0dlll9q.js")
R.m(942374)
module.exports=R.m(942374).exports
