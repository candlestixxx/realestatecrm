var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/websites/templates/route.js")
R.c("server/chunks/[root-of-the-server]__0.umkwq._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_websites_templates_route_actions_06tajst.js")
R.m(93632)
module.exports=R.m(93632).exports
