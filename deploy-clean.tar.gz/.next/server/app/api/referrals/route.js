var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/referrals/route.js")
R.c("server/chunks/[root-of-the-server]__0ejf~~b._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_referrals_route_actions_0yyc8a9.js")
R.m(372431)
module.exports=R.m(372431).exports
