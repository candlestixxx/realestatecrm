var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/gamification/route.js")
R.c("server/chunks/[root-of-the-server]__0w7w.6d._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_gamification_route_actions_0fjgeg3.js")
R.m(334196)
module.exports=R.m(334196).exports
