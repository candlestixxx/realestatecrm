var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lead-gen/social/route.js")
R.c("server/chunks/[root-of-the-server]__11u-x5v._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_lead-gen_social_route_actions_0~0caja.js")
R.m(705859)
module.exports=R.m(705859).exports
