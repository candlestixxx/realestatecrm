var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/avatar/route.js")
R.c("server/chunks/[root-of-the-server]__0to28gi._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/_next-internal_server_app_api_avatar_route_actions_0_y0blb.js")
R.m(870864)
module.exports=R.m(870864).exports
