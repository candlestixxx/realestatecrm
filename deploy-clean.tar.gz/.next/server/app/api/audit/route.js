var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/audit/route.js")
R.c("server/chunks/[root-of-the-server]__0zo0qzw._.js")
R.c("server/chunks/_0sq5ska._.js")
R.c("server/chunks/node_modules_next_dist_10rh~yz._.js")
R.c("server/chunks/[root-of-the-server]__0fygnm6._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_next-internal_server_app_api_audit_route_actions_0r2xp-g.js")
R.m(259999)
module.exports=R.m(259999).exports
