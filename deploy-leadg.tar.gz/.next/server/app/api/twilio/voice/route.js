"use strict";(()=>{var e={};e.id=6054,e.ids=[6054],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},82482:(e,a,t)=>{t.r(a),t.d(a,{originalPathname:()=>m,patchFetch:()=>v,requestAsyncStorage:()=>u,routeModule:()=>l,serverHooks:()=>c,staticGenerationAsyncStorage:()=>d});var r={};t.r(r),t.d(r,{POST:()=>p});var o=t(49303),i=t(88716),n=t(60670),s=t(87070);async function p(e){let a=(await e.formData()).get("CallSid"),t=new URL(e.url),r=t.searchParams.get("agentId")||"default",o=t.searchParams.get("leadId")||"",i=t.searchParams.get("campaignId")||"",n=e.headers.get("host")||process.env.BASE_URL?.replace(/^https?:\/\//,"")||"localhost:3000",p=`wss://${n}/api/twilio/stream`,l=`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Connect>
    <Stream url="${p}">
      <Parameter name="agentId" value="${r}" />
      <Parameter name="leadId" value="${o}" />
      <Parameter name="campaignId" value="${i}" />
      <Parameter name="callSid" value="${a}" />
    </Stream>
  </Connect>
</Response>`;return new s.NextResponse(l,{headers:{"Content-Type":"text/xml"}})}let l=new o.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/twilio/voice/route",pathname:"/api/twilio/voice",filename:"route",bundlePath:"app/api/twilio/voice/route"},resolvedPagePath:"C:\\Users\\hyper\\workspace\\realestatecrm\\apps\\leadg\\src\\app\\api\\twilio\\voice\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:u,staticGenerationAsyncStorage:d,serverHooks:c}=l,m="/api/twilio/voice/route";function v(){return(0,n.patchFetch)({serverHooks:c,staticGenerationAsyncStorage:d})}}};var a=require("../../../../webpack-runtime.js");a.C(e);var t=e=>a(a.s=e),r=a.X(0,[8948,5972],()=>t(82482));module.exports=r})();