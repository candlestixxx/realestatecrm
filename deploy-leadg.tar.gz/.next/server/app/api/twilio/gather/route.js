(()=>{var e={};e.id=1473,e.ids=[1473],e.modules={53524:e=>{"use strict";e.exports=require("@prisma/client")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},57147:e=>{"use strict";e.exports=require("fs")},13685:e=>{"use strict";e.exports=require("http")},95687:e=>{"use strict";e.exports=require("https")},87561:e=>{"use strict";e.exports=require("node:fs")},84492:e=>{"use strict";e.exports=require("node:stream")},72477:e=>{"use strict";e.exports=require("node:stream/web")},71017:e=>{"use strict";e.exports=require("path")},85477:e=>{"use strict";e.exports=require("punycode")},12781:e=>{"use strict";e.exports=require("stream")},57310:e=>{"use strict";e.exports=require("url")},73837:e=>{"use strict";e.exports=require("util")},71267:e=>{"use strict";e.exports=require("worker_threads")},59796:e=>{"use strict";e.exports=require("zlib")},62711:(e,t,s)=>{"use strict";s.r(t),s.d(t,{originalPathname:()=>v,patchFetch:()=>S,requestAsyncStorage:()=>f,routeModule:()=>y,serverHooks:()=>w,staticGenerationAsyncStorage:()=>b});var a={};s.r(a),s.d(a,{POST:()=>p});var n=s(49303),i=s(88716),r=s(60670),o=s(87070),l=s(90279),c=s(54214);class u{constructor(e,t){this.messages=[],this.systemPrompt="",this.callPhase="greeting",this.objectionHistory=[],this.buyingSignals=[],this.openai=e,this.context=t,this.personality=this.getDefaultPersonality()}async initialize(e){if(this.personality=this.parsePersonality(e.personality),this.systemPrompt=this.buildSystemPrompt(e),this.messages.push({role:"system",content:this.systemPrompt,timestamp:Date.now()}),this.context.leadInfo){let e=this.buildLeadContext(this.context.leadInfo);this.messages.push({role:"system",content:e,timestamp:Date.now()})}}buildSystemPrompt(e){let t=this.personality,s=e.qualifyingQuestions||[],a=e.objectionHandling||[],n="";if(e.learningData&&"object"==typeof e.learningData){let t=e.learningData.successfulObjectionHandles||[];t.length>0&&(n=`
## HISTORICAL LEARNINGS (Use these strategies as they have worked in the past)
${t.map(e=>`- ${e}`).join("\n")}
`)}return`You are ${e.name||"Alex"}, an AI sales assistant.

## CORE IDENTITY
You are a ${t.confidence>.7?"highly confident":"warm and approachable"} sales professional with ${t.energy>.7?"high energy and enthusiasm":"a calm, measured demeanor"}.
${t.customTraits?`
## CUSTOM TRAITS
${t.customTraits}`:""}

## COMMUNICATION STYLE
- Verbosity: ${t.verbosity}
- Formality: ${t.formality}
- Humor: ${t.humor}
- Persuasion level: ${t.persuasiveness>.7?"Strong closer - use trial closes, assumptive language":"Consultative - focus on discovery and value"}
- Honesty level: ${t.honesty>.8?"Always be transparent, even if it means losing the sale":"Focus on positive framing without misleading"}

## CONVERSATION RULES
1. Always be genuine and build rapport
2. Listen actively and reference what the prospect says
3. Ask open-ended questions to uncover pain points
4. Match your energy to the prospect's energy
5. Never be pushy — be persistently helpful
6. Handle objections by acknowledging, then redirecting to value
7. Look for buying signals: asking about price, timeline, next steps, implementation

## BUYING SIGNALS TO DETECT
- Asking about pricing, payment terms, or contracts
- Asking about implementation, onboarding, or timeline
- Mentioning budget or decision-making authority
- Asking "how does this work?" or "what would that look like?"
- Expressing urgency about their problem
- Asking about references, case studies, or testimonials
- Saying positive things about the solution

## WHEN TO TRANSFER
Transfer to a human when:
- The prospect explicitly asks to speak to a person
- The conversation becomes too complex for the script
- The prospect is ready to close/sign
- You detect strong buying signals (strength > 0.8)
- The prospect becomes upset or frustrated

${s.length>0?`
## QUALIFYING QUESTIONS (ask naturally, not like a checklist)
${s.map((e,t)=>`${t+1}. ${e}`).join("\n")}
`:""}

${a.length>0?`
## OBJECTION RESPONSES
${a.map(e=>`
**Objection:** ${e.objection}
**Response:** ${e.response}
`).join("\n")}
`:""}

## OBJECTION HANDLING FRAMEWORK
When you hear an objection:
1. Acknowledge: "I completely understand that..."
2. Clarify: "Can you tell me more about what's holding you back?"
3. Reframe: Present the value from a different angle
4. Check: "Does that address your concern?"
${n}
## RESPONSE FORMAT
Respond conversationally. Keep responses under 3 sentences unless explaining something specific.
Never use bullet points or lists in speech — speak naturally as if on the phone.
${t.prohibitedTopics?.length?`
## PROHIBITED TOPICS
Do not discuss: ${t.prohibitedTopics.join(", ")}`:""}`}async processInput(e){let t;this.messages.push({role:"user",content:e,timestamp:Date.now()});let s=await this.analyzeInput(e);this.updatePhase(s);let a=(await this.openai.chat.completions.create({model:"gpt-4o",messages:this.messages.map(e=>({role:e.role,content:e.content})),temperature:.7,max_tokens:200,functions:[{name:"decide_action",description:"Decide the next action based on the conversation state",parameters:{type:"object",properties:{action:{type:"string",enum:["continue","transfer","schedule_callback","schedule_meeting","leave_voicemail","end_call","qualifying","closing"]},should_transfer:{type:"boolean"},transfer_reason:{type:"string"},sentiment:{type:"number",minimum:-1,maximum:1},buying_signal_strength:{type:"number",minimum:0,maximum:1}},required:["action","should_transfer","sentiment","buying_signal_strength"]}}],function_call:{name:"decide_action"}})).choices[0].message,n=a.content||"";try{t=JSON.parse(a.function_call?.arguments||"{}")}catch{t={action:"continue",should_transfer:!1,sentiment:0,buying_signal_strength:0}}this.messages.push({role:"assistant",content:n,timestamp:Date.now()}),t.buying_signal_strength>.5&&this.buyingSignals.push(e);let i=t.should_transfer||t.buying_signal_strength>.8||this.shouldForceTransfer(e);return{response:n,action:i?"transfer":t.action,sentiment:t.sentiment||0,buyingSignalStrength:t.buying_signal_strength||0,shouldTransfer:i,metadata:{phase:this.callPhase,messageCount:this.messages.length,buyingSignals:this.buyingSignals.length,objectionCount:this.objectionHistory.length}}}async analyzeInput(e){let t=e.toLowerCase();return{isObjection:[/not interested/i,/too expensive/i,/already have/i,/bad time/i,/call back later/i,/send (me )?an? email/i,/not (the )?right (time|fit)/i,/think(ing)? about it/i,/need to (talk|discuss) (to|with)/i,/budget/i,/can'?t afford/i].some(e=>e.test(t)),isBuyingSignal:[/how much/i,/what('s| is) the (price|cost)/i,/when (can|could|would)/i,/how (does|do) (it|you|that) (work|help)/i,/next steps/i,/sign(ing)? up/i,/get start(ed)?/i,/implementation/i,/onboarding/i,/timeline/i,/contract/i].some(e=>e.test(t)),sentiment:this.estimateSentiment(t),isQuestion:e.includes("?")}}estimateSentiment(e){let t=0;for(let s of["great","perfect","love","yes","absolutely","interested","definitely","sounds good","exactly","amazing","wonderful","fantastic","impressed","helpful"])e.includes(s)&&(t+=.15);for(let s of["no","stop","hate","terrible","worst","annoying","spam","remove","never","awful","waste","scam","fraud"])e.includes(s)&&(t-=.2);return Math.max(-1,Math.min(1,t))}updatePhase(e){e.isObjection?(this.objectionHistory.push(this.messages[this.messages.length-1]?.content||""),this.callPhase="objection_handling"):e.isBuyingSignal?this.callPhase="closing":this.messages.length<4?this.callPhase="greeting":this.messages.length<10?this.callPhase="qualifying":this.callPhase="presenting"}shouldForceTransfer(e){return[/speak to (someone|a person|a human|your manager|your supervisor)/i,/transfer me/i,/get me someone/i,/let me talk/i,/real person/i].some(t=>t.test(e))}buildLeadContext(e){return`## CURRENT LEAD INFORMATION
Name: ${e.firstName} ${e.lastName}
${e.company?`Company: ${e.company}`:""}
${e.title?`Title: ${e.title}`:""}
${e.customFields?`Context / Custom Variables:
${Object.entries(e.customFields).map(([e,t])=>`- ${e}: ${t}`).join("\n")}`:""}

Use this information to heavily personalize your conversation naturally. If a context variable gives a specific reason for calling (e.g. "need"), adapt your greeting and pitch to directly address it.
Don't reveal that you are reading from a CRM, sound completely human and natural.`}async generateVoicemailScript(){let e=this.messages.slice(-4).filter(e=>"system"!==e.role).map(e=>`${e.role}: ${e.content}`).join("\n");return(await this.openai.chat.completions.create({model:"gpt-4o",messages:[{role:"system",content:`Generate a brief, natural voicemail message (under 30 seconds when spoken).
          Be warm, mention the lead's name, your name, a brief value proposition, and a callback number.
          Speak naturally — this will be converted to speech.`},{role:"user",content:`Context from attempted call:
${e}

Lead: ${this.context.leadInfo?.firstName}`}],temperature:.7,max_tokens:150})).choices[0].message.content||""}getTranscript(){return this.messages.filter(e=>"system"!==e.role)}getSummary(){let e=this.messages.filter(e=>"system"!==e.role).map((e,t)=>0);return{totalMessages:this.messages.filter(e=>"system"!==e.role).length,phases:[this.callPhase],buyingSignals:this.buyingSignals,objections:this.objectionHistory,overallSentiment:e.length>0?e.reduce((e,t)=>e+t,0)/e.length:0}}getDefaultPersonality(){return{persuasiveness:.6,honesty:.9,confidence:.7,energy:.6,empathy:.7,verbosity:"moderate",formality:"professional",humor:"light"}}parsePersonality(e){return e?{...this.getDefaultPersonality(),...e}:this.getDefaultPersonality()}}let m=new Map;async function p(e){let t=await e.formData(),s=t.get("CallSid"),a=t.get("SpeechResult");t.get("Confidence");let n=new URL(e.url),i=n.searchParams.get("agentId"),r=n.searchParams.get("leadId"),p=n.searchParams.get("campaignId"),y="true"===n.searchParams.get("retry");if(!i)return d("Missing agentId parameter.");if(!s)return o.NextResponse.json({error:"CallSid is required"},{status:400});let f=m.get(s);if(!f){let e;let t=await l._.aiAgent.findUnique({where:{id:i}});if(!t)return d("Configuration error.");if(r){let t=await l._.lead.findUnique({where:{id:r}});t&&(e={firstName:t.firstName,lastName:t.lastName,company:t.company||void 0,title:t.title||void 0,customFields:t.customFields})}f=new u(new c.default({apiKey:process.env.OPENAI_API_KEY}),{agentId:t.id,leadId:r||void 0,campaignId:p||void 0,callSid:s,direction:"outbound",leadInfo:e}),await f.initialize({name:t.name,personality:t.personality,systemPrompt:t.systemPrompt,qualifyingQuestions:t.qualifyingQuestions,objectionHandling:t.objectionHandling}),m.set(s,f),setTimeout(()=>m.delete(s),18e5)}if(!a&&y)return h("I understand you might be busy. I'll just need a moment of your time.",i,r,p,s);if(!a)return h("I didn't catch that, could you say that again?",i,r,p,s);let b=await f.processInput(a);if(await l._.callLog.updateMany({where:{twilioCallSid:s},data:{transcript:f.getTranscript().map(e=>`${e.role}: ${e.content}`).join("\n"),sentiment:b.sentiment,..."transfer"===b.action?{status:"TRANSFERRED",transferredAt:new Date}:{},..."end_call"===b.action?{status:"COMPLETED",endedAt:new Date,outcome:b.metadata?.outcome||"NOT_INTERESTED"}:{}}}),b.shouldTransfer||"transfer"===b.action){let e=process.env.TRANSFER_NUMBER||"+15551234567",t=`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Matthew">${g(b.response)}</Say>
  <Say voice="Polly.Matthew">One moment while I connect you with our team.</Say>
  <Dial action="/api/twilio/transfer-complete?callSid=${s}" timeout="30">
    <Number>${e}</Number>
  </Dial>
  <Say voice="Polly.Matthew">It seems they're unavailable right now. Let me take a message.</Say>
  <Record action="/api/twilio/voicemail?callSid=${s}" maxLength="120" playBeep="true"/>
</Response>`;return m.delete(s),new o.NextResponse(t,{headers:{"Content-Type":"text/xml"}})}if("schedule_callback"===b.action||"schedule_meeting"===b.action){let e=`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Matthew">${g(b.response)}</Say>
  <Say voice="Polly.Matthew">Let me take down the best time for us to reconnect. After the beep, please say your preferred date and time.</Say>
  <Record action="/api/twilio/schedule-callback?callSid=${s}&agentId=${i}&leadId=${r}"
          maxLength="60" playBeep="true"/>
</Response>`;return m.delete(s),new o.NextResponse(e,{headers:{"Content-Type":"text/xml"}})}if("leave_voicemail"===b.action||"end_call"===b.action){let e=`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Matthew">${g(b.response)}</Say>
  <Hangup/>
</Response>`;return m.delete(s),new o.NextResponse(e,{headers:{"Content-Type":"text/xml"}})}return h(b.response,i,r,p,s)}function h(e,t,s,a,n){let i=`agentId=${t}&leadId=${s||""}&campaignId=${a||""}&callSid=${n}`,r=`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Matthew">${g(e)}</Say>
  <Gather input="speech" action="/api/twilio/gather?${i}"
          speechTimeout="auto" speechModel="phone_call" language="en-US" enhanced="true">
  </Gather>
  <Say voice="Polly.Matthew">Are you still there?</Say>
  <Redirect>/api/twilio/gather?${i}&amp;retry=true</Redirect>
</Response>`;return new o.NextResponse(r,{headers:{"Content-Type":"text/xml"}})}function d(e){let t=`<?xml version="1.0" encoding="UTF-8"?>
<Response><Say voice="Polly.Matthew">${g(e)}</Say><Hangup/></Response>`;return new o.NextResponse(t,{headers:{"Content-Type":"text/xml"}})}function g(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}let y=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/twilio/gather/route",pathname:"/api/twilio/gather",filename:"route",bundlePath:"app/api/twilio/gather/route"},resolvedPagePath:"C:\\Users\\hyper\\workspace\\realestatecrm\\apps\\leadg\\src\\app\\api\\twilio\\gather\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:f,staticGenerationAsyncStorage:b,serverHooks:w}=y,v="/api/twilio/gather/route";function S(){return(0,r.patchFetch)({serverHooks:w,staticGenerationAsyncStorage:b})}},13974:e=>{function t(e,t,s,a){return Math.round(e/s)+" "+a+(t>=1.5*s?"s":"")}e.exports=function(e,s){s=s||{};var a,n,i=typeof e;if("string"===i&&e.length>0)return function(e){if(!((e=String(e)).length>100)){var t=/^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);if(t){var s=parseFloat(t[1]);switch((t[2]||"ms").toLowerCase()){case"years":case"year":case"yrs":case"yr":case"y":return 315576e5*s;case"weeks":case"week":case"w":return 6048e5*s;case"days":case"day":case"d":return 864e5*s;case"hours":case"hour":case"hrs":case"hr":case"h":return 36e5*s;case"minutes":case"minute":case"mins":case"min":case"m":return 6e4*s;case"seconds":case"second":case"secs":case"sec":case"s":return 1e3*s;case"milliseconds":case"millisecond":case"msecs":case"msec":case"ms":return s;default:return}}}}(e);if("number"===i&&isFinite(e))return s.long?(a=Math.abs(e))>=864e5?t(e,a,864e5,"day"):a>=36e5?t(e,a,36e5,"hour"):a>=6e4?t(e,a,6e4,"minute"):a>=1e3?t(e,a,1e3,"second"):e+" ms":(n=Math.abs(e))>=864e5?Math.round(e/864e5)+"d":n>=36e5?Math.round(e/36e5)+"h":n>=6e4?Math.round(e/6e4)+"m":n>=1e3?Math.round(e/1e3)+"s":e+"ms";throw Error("val is not a non-empty string or a valid number. val="+JSON.stringify(e))}},90279:(e,t,s)=>{"use strict";s.d(t,{_:()=>n});var a=s(53524);let n=globalThis.prisma??new a.PrismaClient({log:[]})}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[8948,5972,4214],()=>s(62711));module.exports=a})();